#1
def a():
    return 5
print(a())

""" T-Diagrams

function : a()
variable : undefined
value : 5
output : a() > 5

"""

#2
def a():
    return 5
print(a()+a())

""" T-Diagrams

function : a()
variable : undefined
value : 5
output : a() > 5

function : a()
variable : undefined
value : 5
output : a() > 5

final_output : a() + a() > 10

"""
#3
def a():
    return 5
    return 10
print(a())


""" T-Diagrams

function : a()
variable : undefined
value : 5
output : a() > 5 
*As soon as a() function returns 5, the function call will be ended.

"""

#4
def a():
    return 5
    print(10)
print(a())

""" T-Diagrams

function : a()
variable : undefined
value : 5
output : a() > 5 
*As soon as a() function returns 5, the function call will be ended.
Thus, a() function will not call print(10)

"""

#5
def a():
    print(5)
x = a()
print(x)

""" T-Diagrams

function : a()
variable : x 
value : a() 
output : 5, None or Undefined

"""

#6
# def a(b,c):
#     print(b+c)
# print(a(1,2) + a(2,3))

""" T-Digrams

function : a(b,c)
variable : b,c
value : 1,2s
output : 3

function : a(b,c)
variable : b,c
value : 2,3
output : 5

final_output : undefined

"""

#7
def a(b,c):
    return str(b)+str(c)
print(a(2,5))

""" T-Diagrams

function : a(b,c)
variable : b, c
value : 2,5
output : 25
* def a() function will be returned str(b) + str(c). Thus, the a() function will be combined b and c integer
instead of adding both integers.

"""

#8
def a():
    b = 100
    print(b)
    if b < 10:
        return 5
    else:
        return 10
    return 7
print(a())

""" T-Diagrams

function : a()
variable : b
value : 100
output : 100, 10 (since b = 100 is greater than 10)

"""

#9
def a(b,c):
    if b<c:
        return 7
    else:
        return 14
    return 3
print(a(2,3))
print(a(5,3))
print(a(2,3) + a(5,3))

""" T-Diagrams

function : a(b,c)
variable : b,c
value : 2,3 
output : 7 (since 2 < 3)

variable : b,c
value : 5,3 
output : 14 (since 5 > 3)

variable : b,c
value : 2,3, 5,3 
output : 21 (7 + 14)

"""

#10
def a(b,c):
    return b+c
    return 10
print(a(3,5))

""" T-Diagrams

function a(b,c)
variable : b,c 
value : 3,5
output : 8
* As soon as b+c is returned from a() function, the function call will be ended. 

"""

#11
# b = 500
# print(b)
# def a():
#     b = 300
#     print(b)
# print(b)
# a()
# print(b)

""" T-Diagrams

variable : b
value : 500
output : 500

function : a()
output : 500
output : 300 ( a() function is used)
output : 500

"""

#12
b = 500
print(b)
def a():
    b = 300
    print(b)
    return b
print(b)
a()
print(b)

""" T-Diagrams

variable : b
value : 500
output : 500

function : a()
output : 500
output : 300
output : 500

"""

#13
b = 500
print(b)
def a():
    b = 300
    print(b)
    return b
print(b)
b=a()
print(b)

""" T-Diagrams

variable : b
value : 500
output : 500

function : a()
output : 500
output : 300,300 ( a() function is used)

"""

#14
def a():
    print(1)
    b()
    print(2)
def b():
    print(3)
a()


""" T-Diagrams

function : a()
variable : undefined
output : 1, 3, 2

"""

#15
def a():
    print(1)
    x = b()
    print(x)
    return 10
def b():
    print(3)
    return 5
y = a()
print(y)

""" T-Diagrams

function : a()
variable : y
value = a()
output : 1, 3, 5, 10

"""
